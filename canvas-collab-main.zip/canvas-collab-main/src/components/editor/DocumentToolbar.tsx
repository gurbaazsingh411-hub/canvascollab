import {
  Bold,
  Italic,
  Underline,
  Strikethrough,
  AlignLeft,
  AlignCenter,
  AlignRight,
  List,
  ListOrdered,
  Link2,
  Image,
  Code,
  Quote,
  Heading1,
  Heading2,
  Heading3,
  Undo,
  Redo,
  Minus,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Separator } from "@/components/ui/separator";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface ToolbarButtonProps {
  icon: React.ElementType;
  label: string;
  active?: boolean;
  onClick?: () => void;
}

function ToolbarButton({ icon: Icon, label, active, onClick }: ToolbarButtonProps) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <button
          onClick={onClick}
          className={cn("toolbar-button", active && "active")}
        >
          <Icon className="h-4 w-4" />
        </button>
      </TooltipTrigger>
      <TooltipContent side="bottom" className="text-xs">
        {label}
      </TooltipContent>
    </Tooltip>
  );
}

export function DocumentToolbar() {
  return (
    <div className="floating-toolbar flex items-center gap-0.5 p-1">
      {/* History */}
      <ToolbarButton icon={Undo} label="Undo (⌘Z)" />
      <ToolbarButton icon={Redo} label="Redo (⌘⇧Z)" />

      <Separator orientation="vertical" className="mx-1 h-6" />

      {/* Headings */}
      <ToolbarButton icon={Heading1} label="Heading 1" />
      <ToolbarButton icon={Heading2} label="Heading 2" />
      <ToolbarButton icon={Heading3} label="Heading 3" />

      <Separator orientation="vertical" className="mx-1 h-6" />

      {/* Text Formatting */}
      <ToolbarButton icon={Bold} label="Bold (⌘B)" />
      <ToolbarButton icon={Italic} label="Italic (⌘I)" />
      <ToolbarButton icon={Underline} label="Underline (⌘U)" />
      <ToolbarButton icon={Strikethrough} label="Strikethrough" />
      <ToolbarButton icon={Code} label="Inline Code" />

      <Separator orientation="vertical" className="mx-1 h-6" />

      {/* Alignment */}
      <ToolbarButton icon={AlignLeft} label="Align Left" active />
      <ToolbarButton icon={AlignCenter} label="Align Center" />
      <ToolbarButton icon={AlignRight} label="Align Right" />

      <Separator orientation="vertical" className="mx-1 h-6" />

      {/* Lists */}
      <ToolbarButton icon={List} label="Bullet List" />
      <ToolbarButton icon={ListOrdered} label="Numbered List" />

      <Separator orientation="vertical" className="mx-1 h-6" />

      {/* Insert */}
      <ToolbarButton icon={Link2} label="Insert Link" />
      <ToolbarButton icon={Image} label="Insert Image" />
      <ToolbarButton icon={Quote} label="Block Quote" />
      <ToolbarButton icon={Minus} label="Horizontal Rule" />
    </div>
  );
}
