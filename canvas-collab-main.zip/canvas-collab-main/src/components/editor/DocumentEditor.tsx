import { useState } from "react";
import { DocumentToolbar } from "./DocumentToolbar";
import { CollaboratorPresence } from "./CollaboratorPresence";

interface DocumentEditorProps {
  documentId?: string;
  initialContent?: string;
}

export function DocumentEditor({ documentId, initialContent = "" }: DocumentEditorProps) {
  const [content, setContent] = useState(initialContent);

  // Mock collaborators for demo
  const collaborators = [
    { id: "1", name: "Alice Chen", color: "hsl(280, 100%, 60%)" },
    { id: "2", name: "Bob Smith", color: "hsl(200, 100%, 50%)" },
  ];

  return (
    <div className="flex h-full flex-col">
      {/* Toolbar */}
      <div className="sticky top-0 z-10 flex items-center justify-between border-b border-border bg-background/95 backdrop-blur px-6 py-3">
        <DocumentToolbar />
        <CollaboratorPresence collaborators={collaborators} />
      </div>

      {/* Editor Canvas */}
      <div className="flex-1 overflow-y-auto px-6 py-8 scrollbar-thin">
        <div className="mx-auto max-w-3xl">
          <div className="document-canvas min-h-[800px] p-12">
            {/* Title */}
            <input
              type="text"
              placeholder="Untitled Document"
              className="mb-6 w-full border-none bg-transparent text-4xl font-bold text-foreground placeholder:text-muted-foreground/50 focus:outline-none"
              defaultValue="Untitled Document"
            />

            {/* Content area */}
            <div
              contentEditable
              className="prose prose-lg dark:prose-invert max-w-none focus:outline-none min-h-[600px]"
              onInput={(e) => setContent(e.currentTarget.innerHTML)}
              suppressContentEditableWarning
            >
              <p className="text-muted-foreground">
                Start typing your document content here...
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Status Bar */}
      <div className="flex items-center justify-between border-t border-border bg-muted/30 px-6 py-2 text-xs text-muted-foreground">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-success animate-pulse" />
            Auto-saved
          </span>
          <span>Last edit: Just now</span>
        </div>
        <div className="flex items-center gap-4">
          <span>Words: 0</span>
          <span>Characters: 0</span>
        </div>
      </div>
    </div>
  );
}
