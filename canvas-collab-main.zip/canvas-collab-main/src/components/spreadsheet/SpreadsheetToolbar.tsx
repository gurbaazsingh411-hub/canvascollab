import {
  Bold,
  Italic,
  Underline,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Paintbrush,
  Type,
  DollarSign,
  Percent,
  Hash,
  Undo,
  Redo,
  Plus,
  Minus,
  Filter,
  SortAsc,
  Snowflake,
} from "lucide-react";
import { Separator } from "@/components/ui/separator";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";

interface ToolbarButtonProps {
  icon: React.ElementType;
  label: string;
  active?: boolean;
  onClick?: () => void;
}

function ToolbarButton({ icon: Icon, label, active, onClick }: ToolbarButtonProps) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <button
          onClick={onClick}
          className={cn("toolbar-button", active && "active")}
        >
          <Icon className="h-4 w-4" />
        </button>
      </TooltipTrigger>
      <TooltipContent side="bottom" className="text-xs">
        {label}
      </TooltipContent>
    </Tooltip>
  );
}

export function SpreadsheetToolbar() {
  return (
    <div className="floating-toolbar flex items-center gap-0.5 p-1">
      {/* History */}
      <ToolbarButton icon={Undo} label="Undo (⌘Z)" />
      <ToolbarButton icon={Redo} label="Redo (⌘⇧Z)" />

      <Separator orientation="vertical" className="mx-1 h-6" />

      {/* Text Formatting */}
      <ToolbarButton icon={Bold} label="Bold" />
      <ToolbarButton icon={Italic} label="Italic" />
      <ToolbarButton icon={Underline} label="Underline" />

      <Separator orientation="vertical" className="mx-1 h-6" />

      {/* Cell Formatting */}
      <ToolbarButton icon={Paintbrush} label="Fill Color" />
      <ToolbarButton icon={Type} label="Text Color" />

      <Separator orientation="vertical" className="mx-1 h-6" />

      {/* Alignment */}
      <ToolbarButton icon={AlignLeft} label="Align Left" active />
      <ToolbarButton icon={AlignCenter} label="Align Center" />
      <ToolbarButton icon={AlignRight} label="Align Right" />

      <Separator orientation="vertical" className="mx-1 h-6" />

      {/* Number Formats */}
      <ToolbarButton icon={DollarSign} label="Currency Format" />
      <ToolbarButton icon={Percent} label="Percent Format" />
      <ToolbarButton icon={Hash} label="Number Format" />

      <Separator orientation="vertical" className="mx-1 h-6" />

      {/* Row/Column */}
      <ToolbarButton icon={Plus} label="Insert Row/Column" />
      <ToolbarButton icon={Minus} label="Delete Row/Column" />
      <ToolbarButton icon={Snowflake} label="Freeze Rows/Columns" />

      <Separator orientation="vertical" className="mx-1 h-6" />

      {/* Data */}
      <ToolbarButton icon={Filter} label="Filter" />
      <ToolbarButton icon={SortAsc} label="Sort" />
    </div>
  );
}
