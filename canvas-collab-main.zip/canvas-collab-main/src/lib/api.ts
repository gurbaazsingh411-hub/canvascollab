import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

export type Document = Database["public"]["Tables"]["documents"]["Row"];
export type DocumentInsert = Database["public"]["Tables"]["documents"]["Insert"];
export type DocumentUpdate = Database["public"]["Tables"]["documents"]["Update"];

export type Spreadsheet = Database["public"]["Tables"]["spreadsheets"]["Row"];
export type SpreadsheetInsert = Database["public"]["Tables"]["spreadsheets"]["Insert"];
export type SpreadsheetUpdate = Database["public"]["Tables"]["spreadsheets"]["Update"];

export type SpreadsheetCell = Database["public"]["Tables"]["spreadsheet_cells"]["Row"];
export type SpreadsheetCellInsert = Database["public"]["Tables"]["spreadsheet_cells"]["Insert"];

export type DocumentPermission = Database["public"]["Tables"]["document_permissions"]["Row"];
export type DocumentRole = Database["public"]["Enums"]["document_role"];

export type Profile = Database["public"]["Tables"]["profiles"]["Row"];

// Documents API
export const documentsApi = {
  async getAll() {
    const { data, error } = await supabase
      .from("documents")
      .select("*, profiles:owner_id(display_name, avatar_url)")
      .order("updated_at", { ascending: false });
    
    if (error) throw error;
    return data;
  },

  async getById(id: string) {
    const { data, error } = await supabase
      .from("documents")
      .select("*, profiles:owner_id(display_name, avatar_url)")
      .eq("id", id)
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async create(document: DocumentInsert) {
    const { data, error } = await supabase
      .from("documents")
      .insert(document)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async update(id: string, updates: DocumentUpdate) {
    const { data, error } = await supabase
      .from("documents")
      .update(updates)
      .eq("id", id)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async delete(id: string) {
    const { error } = await supabase
      .from("documents")
      .delete()
      .eq("id", id);
    
    if (error) throw error;
  },

  async toggleStar(id: string, starred: boolean) {
    return this.update(id, { starred });
  },
};

// Spreadsheets API
export const spreadsheetsApi = {
  async getAll() {
    const { data, error } = await supabase
      .from("spreadsheets")
      .select("*, profiles:owner_id(display_name, avatar_url)")
      .order("updated_at", { ascending: false });
    
    if (error) throw error;
    return data;
  },

  async getById(id: string) {
    const { data, error } = await supabase
      .from("spreadsheets")
      .select("*, profiles:owner_id(display_name, avatar_url)")
      .eq("id", id)
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async create(spreadsheet: SpreadsheetInsert) {
    const { data, error } = await supabase
      .from("spreadsheets")
      .insert(spreadsheet)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async update(id: string, updates: SpreadsheetUpdate) {
    const { data, error } = await supabase
      .from("spreadsheets")
      .update(updates)
      .eq("id", id)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async delete(id: string) {
    const { error } = await supabase
      .from("spreadsheets")
      .delete()
      .eq("id", id);
    
    if (error) throw error;
  },

  async toggleStar(id: string, starred: boolean) {
    return this.update(id, { starred });
  },
};

// Spreadsheet Cells API
export const cellsApi = {
  async getBySpreadsheet(spreadsheetId: string) {
    const { data, error } = await supabase
      .from("spreadsheet_cells")
      .select("*")
      .eq("spreadsheet_id", spreadsheetId);
    
    if (error) throw error;
    return data;
  },

  async upsertCell(cell: SpreadsheetCellInsert) {
    const { data, error } = await supabase
      .from("spreadsheet_cells")
      .upsert(cell, { onConflict: "spreadsheet_id,cell_key" })
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async deleteCell(spreadsheetId: string, cellKey: string) {
    const { error } = await supabase
      .from("spreadsheet_cells")
      .delete()
      .eq("spreadsheet_id", spreadsheetId)
      .eq("cell_key", cellKey);
    
    if (error) throw error;
  },
};

// Permissions API
export const permissionsApi = {
  async getDocumentPermissions(documentId: string) {
    const { data, error } = await supabase
      .from("document_permissions")
      .select("*, profiles:user_id(display_name, email, avatar_url)")
      .eq("document_id", documentId);
    
    if (error) throw error;
    return data;
  },

  async getSpreadsheetPermissions(spreadsheetId: string) {
    const { data, error } = await supabase
      .from("document_permissions")
      .select("*, profiles:user_id(display_name, email, avatar_url)")
      .eq("spreadsheet_id", spreadsheetId);
    
    if (error) throw error;
    return data;
  },

  async addPermission(permission: Database["public"]["Tables"]["document_permissions"]["Insert"]) {
    const { data, error } = await supabase
      .from("document_permissions")
      .insert(permission)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async updatePermission(id: string, role: DocumentRole) {
    const { data, error } = await supabase
      .from("document_permissions")
      .update({ role })
      .eq("id", id)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async removePermission(id: string) {
    const { error } = await supabase
      .from("document_permissions")
      .delete()
      .eq("id", id);
    
    if (error) throw error;
  },
};

// Profiles API
export const profilesApi = {
  async getById(id: string) {
    const { data, error } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", id)
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async update(id: string, updates: Database["public"]["Tables"]["profiles"]["Update"]) {
    const { data, error } = await supabase
      .from("profiles")
      .update(updates)
      .eq("id", id)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async searchByEmail(email: string) {
    const { data, error } = await supabase
      .from("profiles")
      .select("*")
      .ilike("email", `%${email}%`)
      .limit(10);
    
    if (error) throw error;
    return data;
  },
};
